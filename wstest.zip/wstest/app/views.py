# Create your views here.

from django.shortcuts import render, HttpResponse# 引入HttpResponse
from dwebsocket.decorators import accept_websocket  # 引入dwbsocket的accept_websocket装饰器
import json, uuid


# 开始界面
def indexpage(request):
    # 保存客户端的ws对象，以便给客户端发送消息,每个客户端分配一个唯一标识
    userid = str(uuid.uuid1())[:8]
    return render(request, 'index.html', {'userid': userid})


# 服务器方法，监听客户端的websocket链接
clients = {}  # 创建客户端列表，存储所有在线客户端


# 服务器方法，允许接受ws请求
# 负责处理客户端在线列表，处理客户端的请求
# 这里没有将消息发送的代码写在里面，把发送的代码单独构建了一个方法
@accept_websocket
def chat(request):
    # 判断是不是ws请求,如果是个websocket请求返回True，如果是个普通的http请求返回False
    if request.is_websocket():

        userid = request.GET['userid']
        clients[userid] = request.websocket
        # 判断是否有客户端发来消息，若有则进行处理，表示客户端与服务器建立链接成功
        while True:
            '''获取消息，线程会阻塞，
            他会等待客户端发来下一条消息,直到关闭后才会返回，当关闭时返回None'''
            message = request.websocket.wait()
            if not message:
                break
            else:
                msg = str(message, encoding="utf-8")
                # msg = str(message)
                print(msg)
                # 1、发来test表示链接成功
                if msg == "success_link":
                    print("客户端链接成功：" + userid)
                    # 第一次进入，返回在线列表和他的id
                    request.websocket.send(
                        json.dumps({"type": 0, "userlist": list(clients.keys()), "userid": userid}).encode("'utf-8'"))
                        # json.dumps({"type": 0, "userlist": list(clients.keys()), "userid": userid}))
                    # 更新所有人的userlist
                    for client in clients:
                        clients[client].send(
                            json.dumps({"type": 0, "userlist": list(clients.keys()), "user": None}).encode("'utf-8'"))
                            # json.dumps({"type": 0, "userlist": list(clients.keys()), "user": None}))
    # 客户端关闭后从列表删除
    if userid in clients:
        del clients[userid]
        print(userid + "离线")
        # 更新所有人的userlist
        for client in clients:
            clients[client].send(
                json.dumps({"type": 0, "userlist": list(clients.keys()), "user": None}).encode("'utf-8'"))
                # json.dumps({"type": 0, "userlist": list(clients.keys()), "user": None}))


# 接收到消息发送的请求之后，判断是群聊消息还是单聊消息，根据指定的类型发送给不同的目标用户
# 消息发送方法
def msg_send(request):
    # 获取消息
    msg = request.POST.get("txt")
    # 获取发送方id和接收方id
    useridto = request.POST.get("userto")
    useridfrom = request.POST.get("userfrom")
    # type为消息类型，1为群发，否则为指定发给某个用户
    type = request.POST.get("type")
    # 发来{type:"2",msg:data,user:user},表示发送聊天信息，user为空表示群组消息，不为空表示要发送至的用户
    if type == "1":
        # 群发
        for client in clients:
            clients[client].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
            # clients[client].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}))
    else:
        # 私聊，自己显示，颜色为蓝色
        if useridto == useridfrom:
            clients[useridfrom].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
            # clients[useridfrom].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}))
        else:
            # 私聊，自己显示
            clients[useridfrom].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
            # clients[useridfrom].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}))
            # 私聊，对方显示
            clients[useridto].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
            # clients[useridto].send(json.dumps({"type": 1, "data": {"msg": msg, "user": useridfrom}}))

    return HttpResponse(json.dumps({"msg": "success"}))


# 页面跳转
# 聊天界面
def to_chat(request):
    if request.method == 'GET':
        userid = request.GET['userid']
        print(userid)
    return render(request, 'chat.html', {'userid': userid})

# def to_chat2(request):
#     return render(request,'chat2.html')
#
# def to_chat3(request):
#     return render(request,'chat3.html')
#
# def to_chat4(request):
#     return render(request,'chat4.html')

