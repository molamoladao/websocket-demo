"""wstest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
import app.views as views

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$', views.indexpage),
    url(r'^to_chat/$', views.to_chat),
    url(r'^chat/$', views.chat),
    url(r'^msg_send/$', views.msg_send),
    # 聊天
    #path('to_chat/', views.to_chat),
    #path('to_chat2/$', views.to_chat),
    #path('to_chat3/$', views.to_chat),
    #path('to_chat4/$', views.to_chat),

    #path('chat/', views.chat),
    #path('chat2/', views.chat),
   # path('chat3/', views.chat),
    #path('chat4/', views.chat),

    #path('msg_send/', views.msg_send),


    ##########################################################
    #path('<str:userid>/', views.chat,name='userid'),


]
